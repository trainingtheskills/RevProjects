package com.revature.util;

public @interface LogCreation {

}
